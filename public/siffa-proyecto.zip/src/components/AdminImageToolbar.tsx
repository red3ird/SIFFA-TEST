import React from 'react';
import { useImageManager } from '../context/ImageManagerContext';
import { UserProfile } from '../types';

interface AdminImageToolbarProps {
  currentUser: UserProfile | null;
  onQuickLoginAdmin?: () => void;
}

export const AdminImageToolbar: React.FC<AdminImageToolbarProps> = ({
  currentUser,
  onQuickLoginAdmin,
}) => {
  const { isEditMode, setIsEditMode, isAdmin, customImages, setCatalogOpen } = useImageManager();

  const customCount = Object.keys(customImages).length;

  if (!isAdmin) {
    return (
      <div
        id="siffa-admin-image-toolbar"
        className="fixed bottom-4 right-4 z-40"
      >
        <button
          onClick={onQuickLoginAdmin}
          className="bg-[#001738]/95 hover:bg-[#001738] text-white border border-emerald-500/30 px-3.5 py-2 rounded-2xl shadow-xl backdrop-blur-md flex items-center gap-2 text-xs font-bold transition-all hover:scale-105 cursor-pointer group"
          title="Ingresar como Administrador para editar imágenes"
        >
          <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs group-hover:rotate-12 transition-transform">
            <i className="fa-solid fa-camera"></i>
          </div>
          <span className="hidden sm:inline">Editor de Imágenes:</span>
          <span className="text-emerald-400 font-extrabold">Acceso Admin</span>
        </button>
      </div>
    );
  }

  return (
    <div
      id="siffa-admin-image-toolbar"
      className="fixed bottom-4 inset-x-4 max-w-4xl mx-auto z-40 bg-[#001738]/95 text-white border-2 border-emerald-500/60 shadow-2xl rounded-2xl p-3 sm:px-5 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 animate-slideUp"
    >
      {/* Left: Status info */}
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center text-sm font-black shadow-md">
            <i className="fa-solid fa-camera"></i>
          </div>
          {isEditMode && (
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full animate-ping"></span>
          )}
        </div>

        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-black tracking-wide text-white uppercase">
              Modo Edición de Imágenes (Admin)
            </span>
            <span
              className={`text-[10px] px-2 py-0.5 rounded-md font-extrabold ${
                isEditMode
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-400/30'
                  : 'bg-slate-700 text-slate-300'
              }`}
            >
              {isEditMode ? 'ACTIVO' : 'PAUSADO'}
            </span>
            {customCount > 0 && (
              <span className="hidden sm:inline-block text-[10px] px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold">
                {customCount} {customCount === 1 ? 'personalizada' : 'personalizadas'}
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-300 hidden sm:block">
            {isEditMode
              ? 'Haz clic sobre cualquier imagen de la web para cambiarla desde tu PC.'
              : 'Modo edición pausado para navegación estándar.'}
          </p>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2 ml-auto">
        <button
          onClick={() => setCatalogOpen(true)}
          className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
          title="Ver lista de todas las imágenes de la plataforma"
        >
          <i className="fa-solid fa-table-cells text-emerald-400"></i>
          <span className="hidden sm:inline">Catálogo de Fotos</span>
        </button>

        <button
          onClick={() => setIsEditMode(!isEditMode)}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            isEditMode
              ? 'bg-emerald-500 text-slate-950 font-black hover:bg-emerald-400 shadow-xs'
              : 'bg-slate-700 text-slate-200 hover:bg-slate-600'
          }`}
          title={isEditMode ? 'Pausar modo edición' : 'Activar modo edición'}
        >
          <i className={`fa-solid ${isEditMode ? 'fa-toggle-on' : 'fa-toggle-off'} text-sm`}></i>
          <span>{isEditMode ? 'Clic para editar: ON' : 'Clic para editar: OFF'}</span>
        </button>
      </div>
    </div>
  );
};
